public class Individuo {
    private int id;
    private int[] vetorDeEscolha;
    private int volumeTotal;
    private int valorTotal;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int[] getVetorDeEscolha() {
        return vetorDeEscolha;
    }

    public void setVetorDeEscolha(int[] vetorDeEscolha) {
        this.vetorDeEscolha = vetorDeEscolha;
    }

    public int getVolumeTotal() {
        return volumeTotal;
    }

    public void setVolumeTotal(int volumeTotal) {
        this.volumeTotal = volumeTotal;
    }

    public int getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(int valorTotal) {
        this.valorTotal = valorTotal;
    }
}
